"""
    Write a python function that implements a simple guessing game

    The function selects a secret value between 0 and 10 and
    returns the number of tries that it took the user to guess the secret

    In each try, if the guess is wrong, it lets the user know if the
    secret is larger or smaller than the last guess
"""


